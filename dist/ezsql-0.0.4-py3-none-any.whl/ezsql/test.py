from tests import test_ezsql

test_ezsql.run_tests()