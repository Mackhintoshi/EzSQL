import os

dbuser = os.environ['EZSQL_DBUSER']
dbpass = os.environ['EZSQL_DBPASS']
dbhost = os.environ['EZSQL_DBHOST']
dbname = os.environ['EZSQL_DBNAME']
